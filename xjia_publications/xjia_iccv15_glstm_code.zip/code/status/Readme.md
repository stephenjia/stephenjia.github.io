This contains status JSON files of running optimizations
