# Guiding Long Short-Memory for Image Caption Generation, ICCV 2015
# Xu Jia, KU Leuven, ESAT-PSI, Dec 2015
# 
# evaluation given output.txt and gt
# export PYTHONPATH=$PYTHONPATH:/users/visics/xjia/src/xujia/image_caption/coco-caption/pycocoevalcap/
# run eval_pycoco.py --dataset flickr8k 
import argparse
from bleu.bleu import Bleu
from meteor.meteor import Meteor
from rouge.rouge import Rouge
from cider.cider import Cider
import json

def read_res(path, dataset): # path is XX/
    res = {} # res is a dictionary 
    fid = open(path+dataset+'/output', 'r')
    cnt = 0
    while True:
        line = fid.readline()
        if not line: break        
        res[cnt]=[]        
        res[cnt].append(line.replace('\n', ' '))
        cnt+=1
    return(res)
        
def read_gts(path, dataset, gt_num): # path is XX/
    fid_list = {}
    gts = {} # gts is a dictionary, each element's value is a list
    for i in range(gt_num):
        cnt = 0
        fid_list[i] = open('%s%s_ref/reference%d'%(path,dataset,i), 'r')
        while True:
            line = fid_list[i].readline()            
            if not line: break
            if i==0: gts[cnt] = []
            gts[cnt].append(line.replace('\n', ' '))
            cnt+=1
    return(gts)
  
def main(params):
    import pdb; pdb.set_trace()
    
    path = params['path']
    dataset = params['dataset']
    gt_num = params['gt_num']
    
    res = read_res(path, dataset)
    gts = read_gts(path, dataset, gt_num)

    print 'setting up scorers...'
    scorers = [
        (Bleu(4), ["Bleu_1", "Bleu_2", "Bleu_3", "Bleu_4"]),
        (Meteor(),"METEOR"),
        (Rouge(), "ROUGE_L"),
        (Cider(), "CIDEr")
    ]

    # =================================================
    # Compute scores
    # =================================================
    eval = {}
    for scorer, method in scorers:
        print 'computing %s score...'%(scorer.method())
        score, scores = scorer.compute_score(gts, res)

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('--path', type=str, default='./', help='path')
    parser.add_argument('--dataset', type=str, default='flickr8k', help='dataset')    
    parser.add_argument('--gt_num', type=int, default=5, help='number of references')
    args = parser.parse_args()
    params = vars(args) # convert to ordinary dict    
    print 'parsed parameters:'
    print json.dumps(params, indent = 2)      
    
    main(params)
