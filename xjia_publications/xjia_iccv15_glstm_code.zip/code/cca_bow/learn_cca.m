% cca with bow representation

%% Guiding Long Short-Memory for Image Caption Generation, ICCV 2015
% Xu Jia, KU Leuven, ESAT-PSI, Dec 2015

p = 4; 
dim_proj = 200;
text_feat_file_train = './word_hist_train.mat';
vis_feat_file_train = './features_fc7_vgg_train.mat';
vis_feat_file = '../data/flickr8k/vgg_feats.mat';

result_path = '../data/flickr8k/';

%dataset_path = '/esat/ruchba/xjia/dataset/Flickr8k/';
%data_basic_path = '/esat/ruchba/xjia/Flickr8k/basic_representation/';
%result_path = '/esat/ruchba/xjia/Flickr8k/cross_retrieval/cca_bow/';

if ~isdir(result_path)
    mkdir(result_path);
end

% bow sentence representation
% word histogram computed based on either image-5sentece pair (word histogram computed based on image-sentence pair can also be used here without much change on performance)
word_hist_train = load(text_feat_file_train);
word_hist = cellfun(@(x)sum(x,2), word_hist_train.word_hist,'UniformOutput',false); 
word_hist = cat(2,word_hist{:}); 
tf = bsxfun(@rdivide, word_hist, sum(word_hist,1)+eps);
idf = size(word_hist,2)./(sum(word_hist>0,2)+1);
bow_tfidf =  bsxfun(@times, tf, log(idf));
dim_txt_feat = size(bow_tfidf,1);
[bow_tfidf_centered, bow_tfidf_mean] = centering(bow_tfidf); % center the data

% image representation
%load(sprintf('%s%s%s',data_basic_path,'image/','features_fc7_vgg_train'));
load(vis_feat_file_train);
dim_vis_feat = size(vis_feat,1);
[vis_feat_centered, vis_feat_mean] = centering(vis_feat); % centralize the data

% learn cca projection matrix
addpath('./crossmodal/release/');
[Wx, D] = CCA2(vis_feat_centered', single(bow_tfidf_centered')); % visual and textual features

% project all data
load(vis_feat_file);
feats = bsxfun(@rdivide, feats, sqrt(sum(feats.^2,1))); % l2 normalization
[vis_feat_centered_all,~] = centering(feats, vis_feat_mean); % center the data
proj_img = vis_feat_centered_all'*Wx(1:dim_vis_feat,1:dim_proj)*(D(1:dim_proj,1:dim_proj).^p);
proj_img = bsxfun(@rdivide, proj_img, sqrt(sum(proj_img.^2,2))); % l2 normalization
proj_img = proj_img';
save(sprintf('%s%s_%d',result_path, 'semantic_rep',dim_proj), 'proj_img');

