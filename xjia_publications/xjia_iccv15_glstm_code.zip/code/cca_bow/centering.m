function [centered_data, data_mean] = centering(data, data_mean)
% data is d by N

if nargin < 2
    data_mean = mean(data,2); % compute mean
end

centered_data = bsxfun(@minus, data, data_mean); % centered data
