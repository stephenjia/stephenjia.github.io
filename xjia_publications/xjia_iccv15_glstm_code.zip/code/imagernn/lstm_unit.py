import numpy as np

def lstm_unit_forward(X, WLSTM, t, tanhC_version, d, Hout, C):
  # Hout, C are 2-d array
  # X, Hin, IFOG, IFOGf are 1-d array
  
  # set input
  Hin = np.zeros((1,WLSTM.shape[0]))
  IFOG = np.zeros((1,d*4))  
  IFOGf = np.zeros((1,d*4))

  prev = np.zeros(d) if t == 0 else Hout[t-1]
  Hin[0,0] = 1
  Hin[0,1:1+d] = X # input, x_t
  Hin[0,1+d:] = prev  # lstm unit hidden output, h_{t-1}
  
  # compute all gate activations. dots:
  IFOG = Hin.dot(WLSTM)
  
  
  # non-linearities
  IFOGf[0,:3*d] = 1.0/(1.0+np.exp(-IFOG[0,:3*d])) # sigmoids; these are the gates
  IFOGf[0,3*d:] = np.tanh(IFOG[0,3*d:]) # tanh
  
  # compute the cell activation
  C[t] = IFOGf[0,:d] * IFOGf[0,3*d:] # i_t times tanh(W_cx Xt+Wcm m_{t-1}, eq (7)
  if t > 0: C[t] += IFOGf[0,d:2*d] * C[t-1] # f_t times c_{t-1}, eq (7)
  if tanhC_version:
    Hout[t] = IFOGf[0,2*d:3*d] * np.tanh(C[t]) # m_t = o_t times c_t, eq (8)
  else:
    Hout[t] = IFOGf[0,2*d:3*d] * C[t]


  return Hin, IFOG, IFOGf, Hout, C
 

def lstm_unit_backward(dHout, WLSTM, t, tanhC_version, Hin, IFOGf, C, d, dC, dWLSTM):
  # dHout, C and dC, dWLSTM are 2-d array, 
  # WLSTM is 2-d array,
  # Hin, IFOGf, dX are vector
  
  dIFOG = np.zeros((1,IFOGf.shape[0]))
  dIFOGf = np.zeros((1,IFOGf.shape[0]))
  

  if tanhC_version:
    tanhCt = np.tanh(C[t]) # recompute this here
    dIFOGf[0,2*d:3*d] = tanhCt * dHout[t]
    # backprop tanh non-linearity first then continue backprop
    dC[t] += (1-tanhCt**2) * (IFOGf[2*d:3*d] * dHout[t])
  else:
    dIFOGf[0,2*d:3*d] = C[t] * dHout[t]
    dC[t] += IFOGf[2*d:3*d] * dHout[t]

  if t > 0:
    dIFOGf[0,d:2*d] = C[t-1] * dC[t]
    dC[t-1] += IFOGf[d:2*d] * dC[t]
  dIFOGf[0,:d] = IFOGf[3*d:] * dC[t]
  dIFOGf[0,3*d:] = IFOGf[:d] * dC[t]

  # backprop activation functions
  dIFOG[0,3*d:] = (1 - IFOGf[3*d:] ** 2) * dIFOGf[0,3*d:]
  y = IFOGf[:3*d]
  dIFOG[0,:3*d] = (y*(1.0-y)) * dIFOGf[0,:3*d]

  # backprop matrix multiply
  dWLSTM += np.outer(Hin, dIFOG)
  dHin = dIFOG.dot(WLSTM.transpose())

  # backprop the identity transforms into Hin
  dX = dHin[0,1:1+d]
  if t > 0:
    dHout[t-1] += dHin[0,1+d:]

  return dC, dX, dHout, dWLSTM
  
  
# lets define a helper function that does a single LSTM tick
def LSTMtick(x, h_prev, c_prev, d,tanhC_version,WLSTM):
  t = 0

  # setup the input vector
  Hin = np.zeros((1,WLSTM.shape[0])) # xt, ht-1, bias
  Hin[t,0] = 1
  Hin[t,1:1+d] = x
  Hin[t,1+d:] = h_prev

  # LSTM tick forward
  IFOG = np.zeros((1, d * 4))
  IFOGf = np.zeros((1, d * 4))
  C = np.zeros((1, d))
  Hout = np.zeros((1, d))
  IFOG[t] = Hin[t].dot(WLSTM)
  IFOGf[t,:3*d] = 1.0/(1.0+np.exp(-IFOG[t,:3*d]))
  IFOGf[t,3*d:] = np.tanh(IFOG[t, 3*d:])
  C[t] = IFOGf[t,:d] * IFOGf[t, 3*d:] + IFOGf[t,d:2*d] * c_prev
  if tanhC_version:
    Hout[t] = IFOGf[t,2*d:3*d] * np.tanh(C[t])
  else:
    Hout[t] = IFOGf[t,2*d:3*d] * C[t]
  # Y = Hout.dot(Wd) + bd
  # return (Y, Hout, C) # return output, new hidden, new cell
  return (Hout, C) # return output, new hidden, new cell    
