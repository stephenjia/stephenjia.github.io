The implementation of the paper:
@inproceedings{Jia-iccv15,
  author    = {Xu Jia and
               Efstratios Gavves and
               Basura Fernando and
               Peter Young and
               Tinne Tuytelaars},
  title     = {Guiding Long Short-Memory for Image Caption Generation},
  booktitle = {{ICCV}}, 
  year      = {2015}
}

* It is built on Andrej Karpathy's Neuraltalk implementation [1].

0. compute VGG16 CNN features and word histogram in advance (the code is not provided in the zip file)
1. use Normalized Canonical Correlation Analysis to compute the semantic embeddings. We use the code provided by Yunchao Gong for paper [2].
2. run driver_context.py to train the LSTM model
3. run eval_sentence_predictions_xu.py to generate image captions

[1] https://github.com/karpathy/neuraltalk
[2] Y. Gong, Q. Ke, M. Isard and S. Lazebnik. A Multi-View Embedding Space for Modeling Internet Images, Tags, and their Semantics. IJCV, 106(2):210-233, 2014.

## License
BSD license.
